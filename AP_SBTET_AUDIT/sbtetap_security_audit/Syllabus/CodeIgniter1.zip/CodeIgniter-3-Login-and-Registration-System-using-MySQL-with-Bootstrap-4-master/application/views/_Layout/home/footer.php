</body>
<script src="<?= base_url("assets/js/popper.min.js"); ?>"></script>
<script src="<?= base_url("assets/js/bootstrap.min.js"); ?>"></script>
</html>